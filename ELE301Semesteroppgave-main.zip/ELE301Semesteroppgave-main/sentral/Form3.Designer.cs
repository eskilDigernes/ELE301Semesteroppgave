﻿namespace sentral
{
    partial class SlettBruker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.txtPin = new System.Windows.Forms.TextBox();
            this.btnAvbryt = new System.Windows.Forms.Button();
            this.btnSlett = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtFornavn = new System.Windows.Forms.TextBox();
            this.txtEpost = new System.Windows.Forms.TextBox();
            this.txtEtternavn = new System.Windows.Forms.TextBox();
            this.cbKortID = new System.Windows.Forms.ComboBox();
            this.btnEndre = new System.Windows.Forms.Button();
            this.dtPickDate = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(57, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 25);
            this.label7.TabIndex = 25;
            this.label7.Text = "pin";
            // 
            // txtPin
            // 
            this.txtPin.Location = new System.Drawing.Point(218, 225);
            this.txtPin.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.txtPin.Name = "txtPin";
            this.txtPin.Size = new System.Drawing.Size(150, 31);
            this.txtPin.TabIndex = 4;
            // 
            // btnAvbryt
            // 
            this.btnAvbryt.Location = new System.Drawing.Point(327, 338);
            this.btnAvbryt.Name = "btnAvbryt";
            this.btnAvbryt.Size = new System.Drawing.Size(112, 34);
            this.btnAvbryt.TabIndex = 8;
            this.btnAvbryt.Text = "avbryt";
            this.btnAvbryt.UseVisualStyleBackColor = true;
            this.btnAvbryt.Click += new System.EventHandler(this.btnAvbryt_Click);
            // 
            // btnSlett
            // 
            this.btnSlett.Location = new System.Drawing.Point(57, 338);
            this.btnSlett.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.btnSlett.Name = "btnSlett";
            this.btnSlett.Size = new System.Drawing.Size(112, 34);
            this.btnSlett.TabIndex = 6;
            this.btnSlett.Text = "slett";
            this.btnSlett.UseVisualStyleBackColor = true;
            this.btnSlett.Click += new System.EventHandler(this.btnSlett_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 272);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 25);
            this.label5.TabIndex = 24;
            this.label5.Text = "gyldighet";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 25);
            this.label4.TabIndex = 23;
            this.label4.Text = "kort id";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(57, 184);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 25);
            this.label3.TabIndex = 21;
            this.label3.Text = "epost";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(57, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 25);
            this.label2.TabIndex = 19;
            this.label2.Text = "fornavn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 25);
            this.label1.TabIndex = 17;
            this.label1.Text = "etternavn";
            // 
            // txtFornavn
            // 
            this.txtFornavn.Location = new System.Drawing.Point(218, 93);
            this.txtFornavn.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.txtFornavn.Name = "txtFornavn";
            this.txtFornavn.Size = new System.Drawing.Size(150, 31);
            this.txtFornavn.TabIndex = 1;
            // 
            // txtEpost
            // 
            this.txtEpost.Location = new System.Drawing.Point(218, 181);
            this.txtEpost.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.txtEpost.Name = "txtEpost";
            this.txtEpost.Size = new System.Drawing.Size(150, 31);
            this.txtEpost.TabIndex = 3;
            // 
            // txtEtternavn
            // 
            this.txtEtternavn.Location = new System.Drawing.Point(218, 137);
            this.txtEtternavn.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.txtEtternavn.Name = "txtEtternavn";
            this.txtEtternavn.Size = new System.Drawing.Size(150, 31);
            this.txtEtternavn.TabIndex = 2;
            // 
            // cbKortID
            // 
            this.cbKortID.FormattingEnabled = true;
            this.cbKortID.Location = new System.Drawing.Point(218, 47);
            this.cbKortID.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.cbKortID.Name = "cbKortID";
            this.cbKortID.Size = new System.Drawing.Size(150, 33);
            this.cbKortID.TabIndex = 0;
            this.cbKortID.SelectedIndexChanged += new System.EventHandler(this.cbKortID_SelectedIndexChanged);
            // 
            // btnEndre
            // 
            this.btnEndre.Location = new System.Drawing.Point(192, 338);
            this.btnEndre.Margin = new System.Windows.Forms.Padding(3, 3, 20, 3);
            this.btnEndre.Name = "btnEndre";
            this.btnEndre.Size = new System.Drawing.Size(112, 34);
            this.btnEndre.TabIndex = 7;
            this.btnEndre.Text = "endre";
            this.btnEndre.UseVisualStyleBackColor = true;
            this.btnEndre.Click += new System.EventHandler(this.btnEndre_Click);
            // 
            // dtPickDate
            // 
            this.dtPickDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtPickDate.Location = new System.Drawing.Point(218, 272);
            this.dtPickDate.Margin = new System.Windows.Forms.Padding(3, 3, 3, 10);
            this.dtPickDate.Name = "dtPickDate";
            this.dtPickDate.Size = new System.Drawing.Size(150, 31);
            this.dtPickDate.TabIndex = 5;
            // 
            // SlettBruker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 424);
            this.Controls.Add(this.dtPickDate);
            this.Controls.Add(this.btnEndre);
            this.Controls.Add(this.cbKortID);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtPin);
            this.Controls.Add(this.btnAvbryt);
            this.Controls.Add(this.btnSlett);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtFornavn);
            this.Controls.Add(this.txtEpost);
            this.Controls.Add(this.txtEtternavn);
            this.Name = "SlettBruker";
            this.Text = "Slett bruker";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label7;
        private TextBox txtPin;
        private Button btnAvbryt;
        private Button btnSlett;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox txtFornavn;
        private TextBox txtEpost;
        private TextBox txtEtternavn;
        private ComboBox cbKortID;
        private Button btnEndre;
        private DateTimePicker dtPickDate;
    }
}