using Microsoft.VisualBasic;
using System.IO.Ports;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace KORTLESERgui
{
    public partial class Form1 : Form
    {
        /*Variabler for simsom*/
        bool kommuniser;
        Thread hjelpetr�d;
        SerialPort sp;
        string enMelding;
        string data;
        public string pin = "";
        public string validering = "";
        public string kortlesernr = "";
        public float time;

        /*Variabler for sentral*/
        bool ferdig;
        Socket klientSokkel;
        string dataFraServer;

        public Form1()
        {
            InitializeComponent();
            OppdaterSeriellePorter();
            kommuniser = false;
        }

        /************KONTAKT MED SIMSIM*****************************************/
        void OppdaterSeriellePorter()
        {
            string[] allePorter = SerialPort.GetPortNames();
            for (int i = 0; i < allePorter.Length; i++)
            {
                cbAlleSeriellePorter.Items.Add(allePorter[i]);
            }
            if (cbAlleSeriellePorter.Items.Count > 0)
            {
                cbAlleSeriellePorter.SelectedIndex = 1;
            }
        }

        void SeriellPortKommunikasjon(object o)
        {
            string comPort = o as string;
        }

        void OppdaterGUI(string enMelding)
        {
            lbLogg.Items.Insert(0, enMelding);
        }

        static string HenteUtEnMelding(string data, ref string enMelding)
        {
            int posStart = data.IndexOf('$');
            int posSlutt = data.IndexOf('#');

            enMelding = data.Substring(posStart, (posSlutt - posStart) + 1);

            if (posStart > 0) data = data.Substring(posStart);
            if (enMelding.Length < data.Length) data = data.Substring(posSlutt + 1);
            else data = "";
            return data;
        }

        static bool DataInneholderEnHelMelding(string data)
        {
            bool svar = false;

            int posStart = data.IndexOf('$');
            int posSlutt = data.IndexOf('#');
            if (posStart != -1 && posSlutt != -1)
            {
                if (posStart < posSlutt)
                {
                    svar = true;
                }
            }
            return svar;
        }

        static string MottaData(SerialPort sp)
        {
            string svar = "";
            try
            {
                svar = sp.ReadExisting();
            }
            catch (Exception err)
            {
                MessageBox.Show("Feil: " + err.ToString());
            }
            return svar;
        }

        static void SendEnMelding(SerialPort s, string melding)
        {
            try
            {
                s.Write(melding);
            }
            catch (Exception err)
            {
                MessageBox.Show("Feil: " + err.ToString());
            }
        }

        public void analyserKode(string kode)
        {
            int indexD = kode.IndexOf('D');

            if (kode[indexD + 1] == '1') pin += '0';
            else if (kode[indexD + 2] == '1') pin += '1';
            else if (kode[indexD + 3] == '1') pin += '2';
            else if (kode[indexD + 4] == '1') pin += '3';

            if (pin.Length <= 4) txtKortID.Text = pin;
            else txtPIN.Text += pin[pin.Length - 1].ToString();

            //For � skru av valgt digital inngang i Simsim etter � ha sendt digital inngang (Simsim har ingen kode for � skru av digital inngang bare for digital utgang s� dette fungerer ikke)
            SendEnMelding(sp, $"$O{pin[pin.Length - 1]}0");

            validering = $"{txtKortID.Text}${pin}${kortlesernr}";
        }

        private void bwSeriellKommunikasjon_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            // Utf�res av en hjelpetr�d n�r RunWorkerAsync-brukes
            bool enHelMeldingMotatt = false;
            enMelding = "";

            while (kommuniser && !enHelMeldingMotatt)
            {
                data = data + MottaData(sp);


                if (DataInneholderEnHelMelding(data))
                {

                    data = HenteUtEnMelding(data, ref enMelding);

                    enHelMeldingMotatt = true;
                }
            }
        }
        private void bwSeriellKommunikasjon_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            // Utf�res av gui-tr�den n�r bw-hjelpetr�dien har avsluttet
            if (kommuniser)
            {
                OppdaterGUI(enMelding);
                analyserKode(enMelding);
                bwSeriellKommunikasjon.RunWorkerAsync();
            }
        }

        /****************Klient*************************/
        static Socket KobleTilServer(out bool ferdig)
        {
            ferdig = false;
            Socket klientSokkel = new Socket(AddressFamily.InterNetwork,
            SocketType.Stream,
            ProtocolType.Tcp);
            IPEndPoint serverEP = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 9050);
            try
            {
                klientSokkel.Connect(serverEP);
            }
            catch (Exception err)
            {

                MessageBox.Show(err.Message);
                ferdig = true;
            }
            return klientSokkel;
        }
        static string MottaTekst(Socket kommSokkel, out bool feilHarOppst�tt)
        {
            string svar = "";
            feilHarOppst�tt = false;

            try
            {
                byte[] data = new byte[1024];
                int antallBytesMottatt = kommSokkel.Receive(data);

                if (antallBytesMottatt > 0) svar = Encoding.ASCII.GetString(data, 0, antallBytesMottatt);
                else feilHarOppst�tt = true;
            }
            catch (Exception err)
            {
                MessageBox.Show("Feil:"+err.ToString());
                feilHarOppst�tt = false;
            }
            return svar;
        }
        static void SendTekst(Socket kommSokkel, string tekstSomSkalSendes, out bool feilHarOppst�tt)
        {
            feilHarOppst�tt = false;
            try
            {
                byte[] data = Encoding.ASCII.GetBytes(tekstSomSkalSendes);
                kommSokkel.Send(data, data.Length, SocketFlags.None);
            }
            catch (Exception unntak)
            {
                MessageBox.Show("Feil: " + unntak.ToString());
                feilHarOppst�tt = true;
            }
        }

        private void btnSendMelding_Click(object sender, EventArgs e)
        {
            btnSendMelding.Enabled = false;
            bwHjelpetr�d.RunWorkerAsync();
        }

        private void Klient_Load(object sender, EventArgs e)
        {
            klientSokkel = KobleTilServer(out ferdig);
            txtKortlesernr.Select();
            timerTick.Start();
            time = 15;

            if (ferdig) Application.Exit();

            if (cbAlleSeriellePorter.SelectedIndex >= 0)
            {
                string comPort = cbAlleSeriellePorter.SelectedItem.ToString();
                kommuniser = true;

                sp = new SerialPort(comPort, 9600);

                try
                {
                    sp.Open();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Feil: " + err.ToString());
                }

                if (sp.IsOpen)
                {
                    SendEnMelding(sp, "$O41");
                    bwSeriellKommunikasjon.RunWorkerAsync();
                }
            }

            SendEnMelding(sp, "$O51");
            label5.Text = MottaTekst(klientSokkel, out ferdig);

        }

        private void bwHjelpetr�d_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            // Arbeid som utf�res i en hjelpetr�d
            if (!ferdig) SendTekst(klientSokkel, validering, out ferdig);
            if (!ferdig)
            {
                dataFraServer = MottaTekst(klientSokkel, out ferdig);
            }
        }

        private void bwHjelpetr�d_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            // Arbeid som utf�res av GUI-tr�den n�r bwHjelpetr�d_DoWork har avsluttet
            if (!ferdig) txtTekstSomSkalSendes.Text = dataFraServer;
            btnSendMelding.Enabled = true;
        }

        private void timerTick_Tick(object sender, EventArgs e)
        {
            if (time > 0) txtTid.Text = time--.ToString();
            else
            {
                if (time == 0)
                {
                    SendEnMelding(sp, "$O40");
                    txtKortlesernr.Text = "";
                    txtKortID.Text = "";
                    txtPIN.Text = "";
                    pin = "";
                    time = -1;
                }
                if(txtKortlesernr.Text.Length > 0 && time == -1)
                {
                    SendEnMelding(sp, "$O41");
                    time = 15;
                }  
            }

            if (txtPIN.Text.Length == 4 && txtKortID.Text.Length == 4 && txtKortlesernr.Text.Length == 4)
            {
                string sentralPin = $"{txtKortID.Text}${txtPIN.Text}${txtKortlesernr.Text}";
                txtKortID.Text = "";
                txtPIN.Text = "";
                pin = "";

                SendTekst(klientSokkel, sentralPin, out ferdig);
                string ValidKode = MottaTekst(klientSokkel, out ferdig);

                if (ValidKode == "True")
                {
                    SendEnMelding(sp, "$O50");
                    MessageBox.Show("Valid");
                }
                else if (ValidKode == "False") MessageBox.Show("Invalid");
            }
        }
    }
}